function [f]=noiseCancel(p)

recObj = audiorecorder(p.hz,16,1,1);
recordblocking(recObj, p.runtimeN+p.offset);
f.nRaw = getaudiodata(recObj);
f.n=f.nRaw(p.offset*p.hz+1:length(f.nRaw))/max(f.nRaw);

f.nFreq = abs(fft(f.n));

f.nFreq=f.nFreq(1:round(length(f.nFreq)/2));
f.nFreq=smooth(f.nFreq,round(p.hz*p.runtimeN/1000));
