function p=initVar

p.hz=16000;
p.smoothWidth=round(0.045*p.hz);
p.smoothIncrem=round(0.015*p.hz);
p.hzs=p.hz/p.smoothIncrem;
p.spaceWidth=round(0.25*p.hzs);
p.minWidth=round(0.1*p.hzs);
p.endWidth=round(1.4*p.hzs);
p.stopWidth=round(3*p.hzs);
p.recd=1;
p.highz=7000;
p.lowhz=1000;
[p.b,p.a] = butter(5, 2*[p.lowhz p.highz]/p.hz, 'bandpass');