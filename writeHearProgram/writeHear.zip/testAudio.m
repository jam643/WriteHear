function [f,p]=testAudio(p,hObject,handles)
guidata(hObject,handles)
i=1;
recObj = audiorecorder(p.hz,16,1,p.recd);
recObj2 = audiorecorder(p.hz,16,1,p.recd);
record(recObj2);

while strcmp(get(handles.testB,'string'),'Stop')
    record(recObj);
    char=0;
    first=1;
    while char==0 && strcmp(get(handles.testB,'string'),'Stop')
        if first
            pause((p.spaceWidth+2)/p.hzs);
            first=0;
        else
            pause(0.5*p.spaceWidth/p.hzs);
        end
        f.xUnfiltRaw{i}= getaudiodata(recObj)';
        [f.x{i},f.E{i}]=filters1(f.xUnfiltRaw{i},p);
        [char,f]=isCharacter(f,p,i);
        if char==1
            stop(recObj);
            f=charStore1(f,p,i);
            i=i+1;
        end
    end
end
stop(recObj);
stop(recObj2);
plots1(f,p)
play(recObj2);
pause(recObj2.TotalSamples/p.hz)